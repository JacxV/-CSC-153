﻿/**
 * 18MAR2022
 * CSC 153
 * Jacquelin Velasquez
 * This program takes a wholesale price and percent mark up and calculates the retail price.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class retailPriceCalculator : Form
    {
        public retailPriceCalculator()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            decimal wholesalePrice;
            decimal markupPercent;
            decimal retailPrice;

                wholesalePrice = decimal.Parse(wholesalePriceTextBox.Text);                  //Store wholeprice entered
                markupPercent = decimal.Parse(markupPercentTextBox.Text) / 100;              //Store markup percentage entered

            retailPrice = calculateRetailPrice(wholesalePrice, markupPercent);              //Method called to calculate retail price

            MessageBox.Show($"Retail Price ${retailPrice}");
        }

        private decimal calculateRetailPrice(decimal price, decimal percent)                //Method to calculate Retail Price
        {
            decimal retailPrice;
            retailPrice = (price * percent) + price;                                       //Caculate retail Price

            return retailPrice;                                                            //Retail price returned to where method was called
        }
    }


}
