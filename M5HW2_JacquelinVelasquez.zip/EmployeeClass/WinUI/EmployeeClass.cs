﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinUI
{
    public class Employee
    {
        string _name;
        string _department;
        string _position;
        int _id;
        public Employee()
        {
            _name = "";
            _department = "";
            _position = "";
            _id = 0;
        }
        public Employee(string name, int id, string dep, string position)
        {
            _name = name;
            _id = id;
            _department = dep;
            _position = position;
        }

        public Employee(string name, int id)
        {
            _name = name;
            _id = id;
            _department = "";
            _position = "";
        }

        public string Name { get{ return _name; } set { _name = value; } } 
        public string Department { get { return _department; } set { _department = value; } }
        public string Position { get { return _position; } set { _position = value; } }
        public int Id { get { return _id; } set { _id = value; } }


    }
}
