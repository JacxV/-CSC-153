﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Employee> employees = new List<Employee>();

            employees.Add(new Employee("Susan Meyers", 47899, "Accounting", "Vice President"));
            employees.Add (new Employee("Mark Jones", 39119, "IT", "Programmer"));
            employees.Add(new Employee("Joy Rogers", 81774, "Manufaturing", "Engineer"));

            foreach (Employee employee in employees)
            {
                employeesListBox.Items.Add($"{employee.Name}\t{employee.Id}"+
                                           $"\t{employee.Department}\t\t\t{employee.Position}");
            }
        }
    }
}
