﻿/**
* 15 April 2022
* CSC 153
* Jacquelin Velasquez
* This program uses a pet class to store a pet's name, type, and age.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsUI
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        Pet userPet = new Pet();
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Name: {userPet.Name}");
            MessageBox.Show($"Type: {userPet.Type}");
            MessageBox.Show($"Age: {userPet.Age}");

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            userPet.Name = nameTextBox.Text;
            userPet.Type = typeTextBox.Text;
            userPet.Age =  int.Parse(ageTextBox.Text);
        }
    }
}
