﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileButton_Click(object sender, EventArgs e)
        {
            StreamReader file;
            int counter = 0;
            int sum = 0;
            int item = 0;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                file = File.OpenText(openFileDialog.FileName);

                while (!file.EndOfStream)
                {
                    item = int.Parse(file.ReadLine());
                    numListBox.Items.Add(item);
                    sum += item;
                    counter++;

                }

                sumLabel.Text = sum.ToString();
                randNumsLabel.Text = counter.ToString();

            }
            else
            {
                MessageBox.Show("Error openning file.");
            }    

        }
    }
}
