﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.amountOfNumsTextBox = new System.Windows.Forms.TextBox();
            this.safeFileButton = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the number of Random numbers you would like to save. (1-100)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // amountOfNumsTextBox
            // 
            this.amountOfNumsTextBox.Location = new System.Drawing.Point(97, 75);
            this.amountOfNumsTextBox.Name = "amountOfNumsTextBox";
            this.amountOfNumsTextBox.Size = new System.Drawing.Size(62, 20);
            this.amountOfNumsTextBox.TabIndex = 1;
            // 
            // safeFileButton
            // 
            this.safeFileButton.Location = new System.Drawing.Point(97, 114);
            this.safeFileButton.Name = "safeFileButton";
            this.safeFileButton.Size = new System.Drawing.Size(62, 23);
            this.safeFileButton.TabIndex = 2;
            this.safeFileButton.Text = "SaveFile";
            this.safeFileButton.UseVisualStyleBackColor = true;
            this.safeFileButton.Click += new System.EventHandler(this.safeFileButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 164);
            this.Controls.Add(this.safeFileButton);
            this.Controls.Add(this.amountOfNumsTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox amountOfNumsTextBox;
        private System.Windows.Forms.Button safeFileButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

