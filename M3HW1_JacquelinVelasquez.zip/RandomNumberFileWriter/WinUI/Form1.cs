﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI{
    public partial class Form1 : Form{
        public Form1(){
            InitializeComponent();
        }

        private void safeFileButton_Click(object sender, EventArgs e) {
        
            try{
                StreamWriter file;
                Random rand = new Random();
                int howMany = int.Parse(amountOfNumsTextBox.Text);
                int randomNum = 0;
                int counter = 1;

                if (saveFileDialog.ShowDialog() == DialogResult.OK){
                    file = File.CreateText(saveFileDialog.FileName);

                    while (counter <= howMany){
                        randomNum = rand.Next(101);
                        file.WriteLine(randomNum);
                        counter++;
                    }
                    file.Close();
                }
                else{
                    MessageBox.Show("Please save file.");
                }
            }
            catch{

                MessageBox.Show("Please enter a valid Integer between 1 and 100.");
            }


        }
    }
}
