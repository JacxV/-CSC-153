﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] answersKey = new string[] { "B", "D", "A", "A", "C",
                                                 "A", "B", "A", "C", "D",
                                                 "B", "C", "D", "A", "D",
                                                 "C", "C", "B", "D", "A" };

            string[] studentAnswers = new string[] {"B", "D", "B", "A", "C",
                                                    "A", "B", "A", "C", "D",
                                                    "B", "C", "D", "C", "D",
                                                    "C", "C", "D", "D", "B" };

            int correctAnswers = 0;
            int incorrectAnswers = 0;
            List<int> missedQ = new List<int>();

            for (int index = 0; index < answersKey.Length; index++){
                if (answersKey[index] == studentAnswers[index]){
                    correctAnswers++;
                }
                else{
                    incorrectAnswers++;
                    missedQ.Add(index + 1);
                }

            }

            if (correctAnswers >= 15)
            {
                MessageBox.Show("Congratulations! You Passed!");
            }
            else
            {
                MessageBox.Show("I'm Sorry! You Failed!");
            }

            correctLabel.Text = correctAnswers.ToString();
            incorrectLabel.Text = incorrectAnswers.ToString();

            foreach (int question in missedQ)
            {
                IncorrectQListBox.Items.Add(question);
            }
        }
    }
}
